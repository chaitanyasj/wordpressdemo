<?php
/*
Plugin Name: vj-plugin for Job Listing
Plugin URI: http://abc.com
Description: plugin by vijay.
Version: 1.1.0
Author:vijay
*/
include_once dirname(__FILE__) . '/all-functions.php';

function myconfig_enqueue_script() {   
	
	wp_enqueue_style( 'vj-style', plugins_url('assets/css/style.css', __FILE__));
	wp_enqueue_script( 'vj-script', plugins_url( 'assets/js/script.js' , __FILE__) );
}
add_action('admin_enqueue_scripts', 'myconfig_enqueue_script',99);

function menu_for_job()
{
  add_menu_page("All Job Settting", "All Job Settting", "manage_options", "all-job-settting", "all_job_function"); 
}
add_action("admin_menu", "menu_for_job");

$job_object = new jobs();

function get_all_content(){
	$job_object = new jobs();
	$result = file_get_contents("https://www.enggwave.com/wp-json/wp/v2/posts/?per_page=2");
	$jsondata = json_decode($result);
	foreach ($jsondata as $data) {
		$job_object->insertJobData($data);
	}
}
// add_action('init','get_all_content');
// add_shortcode('restapi','get_all_content');


function all_job_function(){
	echo "hi vijay!! you are the best:)";
	?>
	<div class="vj_get_all_jobs"> 
     <h1>Get all jobs</h1>
     <form class="vj_form" action="#" method="post">
         <input type="submit" name="submit_fetch_jobs" class="button button-primary button-large" id="submit_fetch_jobs" value="Click to update your jobs"> 
     </form>
    </div> 
<?php
}

function displayData(){
	echo "<div class='job-view'>";
		echo $data->id."<br>";
		echo $data->title->rendered."<br>";
		echo $data->content->rendered."<br>";
		echo $data->excerpt->rendered."<br>";
		echo $data->link."<br>";
		echo "</div>";
}
// add_shortcode('displayData','displayData');

function load_first(){
	$job_object = new jobs();
	if(isset($_POST['submit_fetch_jobs'])){
		$job_object = new jobs();
		$result = file_get_contents("https://www.enggwave.com/wp-json/wp/v2/posts/?per_page=2");
		$jsondata = json_decode($result);
		foreach ($jsondata as $data) {
			$job_object->insertJobData($data);
		}
	}
}

add_action('init','load_first');
